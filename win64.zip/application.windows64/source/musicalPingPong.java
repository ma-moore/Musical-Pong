import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import javax.sound.sampled.AudioFormat; 
import javax.sound.sampled.AudioSystem; 
import javax.sound.sampled.DataLine; 
import javax.sound.sampled.LineUnavailableException; 
import javax.sound.sampled.SourceDataLine; 
import javax.sound.sampled.TargetDataLine; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class musicalPingPong extends PApplet {

/* Welcom to Musical Pong
In this program you play pong against a musical wall (sort of a compination between pong and breakout)
As you hit the wall the spots light up and a note begins to play (each grid location has a different note)
The 'score' is just about how many you can have playing (and for how long), but the real fun is seeing what sounds you make.

The program uses Matthew Yee King's AudioThread library (https://github.com/yeeking/SimpleAudioInProcessing/) to 
play the audio. The audio is set up by a series of different sine waves.
*/

AudioThread audioThread; //The audio player sets up the sounds of the game
Court court; //The background and blocks to hit
Player player; //Operates the player, paddle and bouncing ball
int gameStage; //Changes the game between the start screen, game screen and end screen
float phase, dPhase; //Controls the progression through the sine waves that are the audio


public void setup() //Setups the the primary classes and variables
{
  size (800,800,P3D); 
  court = new Court();
  player = new Player();
  gameStage = 0; 
  
  dPhase = TWO_PI/44100;
  phase = 0;
  
  audioThread = new AudioThread();
}

public void draw()
{
  background(0);
  if (gameStage==0)
  {
    gameStartScreen();
    if (mousePressed) //Mouse click starts the game 
    {
      gameStage = 1;
      audioThread.start(); //Starts the audioThread class which will start the notes playing as soon as the plates are pressed
    }
  }
  else if (gameStage==1)
  {
    court.run(); //Draws the court and the game buttons
    player.run(); //Draws the ball and paddle - and moves&bounces the ball
  }
 else
 {
   gameOverScreen();
   stop(); //Ends the song when the player loses
 }
}

public void gameStartScreen() //Basic opening screen, click to continue with the game
{
  textSize(50);
  fill(255);
  text("Welcome to Musical Tennis",80,300);
  textSize(25);
  text("Hit the blocks to rack up the score and play a song",95,350);
  text("Click with the Mouse to Start",220,380);
}

public void gameOverScreen() //Basic end screen credits
{
  textSize(80);
  fill(255);
  text("Game Over",200,300);
  textSize(50);
  text("Your Score is: "+player.score+".",220,400);
}

public void generateAudioOut(float[] buffer) //Generates the audio buffer 
{ 
  for (int i=0;i<buffer.length; i++) 
  {
    int a = 1;
    for (int n=0;n<court.board.length;n++) //Adds a sine wave from each of the plates - based on whether or not they are pressed. 
    {
      if (court.board[n].pressed) 
      {
        buffer[i] += sin(phase*court.board[n].freq);
        a++;
      }
    }
    buffer[i] = buffer[i]/a; //Divides by the number of sine waves added (to keep the audio within the -1 to 1 range) 
    phase+=dPhase; //Moves through the sine waves by the sample rate. 
  }
}

public void stop()
{
  audioThread.quit();
  super.stop();
}

/*
 *  This file has been adapted from 
 * https://github.com/mhroth/jvsthost/blob/master/src/com/synthbot/audioio/vst/JVstAudioThread.java
 *
 *  which contains the following license:
 *
 * Copyright 2007 - 2009 Martin Roth (mhroth@gmail.com)
 *                        Matthew Yee-King
 * 
 *  JVstHost is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Lesser General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  JVstHost is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 *  
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with JVstHost.  If not, see <http://www.gnu.org/licenses/>.
 *
 */
 







public class AudioThread extends Thread {
  // buffer to store the audio data coming in
  // it's a 2D array as we may have more than one channel
  private  float[][] fInputs;
  // buffer to store the audio data going out
  private  float[][] fOutputs;
  // raw binary buffer which is used to actually send data to the sound card as bytes
  private  byte[] bOutput;
  private  byte[] bInput;
  private byte[] twoBytes;
  // how many samples to process per cycle? 
  private int blockSize;
  // how many audio outputs/ inputs
  private int numOutputs;
  private int numInputs;
  // samples per second
  private int sampleRate;
  private int bitDepth;
  // the type of audio we are going to generate (PCM/compressed etc? )
  // see http://download.oracle.com/javase/1.5.0/docs/api/javax/sound/sampled/AudioFormat.html
  private AudioFormat audioFormat;
  //  used to access outgoing audio resources
  private SourceDataLine sourceDataLine;
  // used to access incoming audio 
  private TargetDataLine targetDataLine;
  // are we running?

  private boolean running;

  // we pull this value into a variable for speed (avoids repeating the field access and cast operation)
  private static final float ShortMaxValueAsFloat = (float) Short.MAX_VALUE;

  // constructor attempts to initialise the audio device
  AudioThread () {
    running = false;
    // mono
    numOutputs = 1;
    numInputs = 1;
    // block size 4096 samples, lower it if you want lower latency
    blockSize = 4096;
    sampleRate = 44100;
    bitDepth = 16;
    // initialise audio buffers
    fInputs = new float[numInputs][blockSize];
    fOutputs = new float[numOutputs][blockSize];
    bOutput = new byte[numOutputs * blockSize * 2];
    bInput = new byte[numInputs * blockSize * 2];
    twoBytes = new byte[2];
    // set up the audio format, 
    audioFormat = new AudioFormat(sampleRate, bitDepth, numOutputs, true, false);
    // create an object which contains the info required to create an audio out
    DataLine.Info audioOutDataLineInfo = new DataLine.Info(SourceDataLine.class, audioFormat);
    // create an object which contains the info required to create an audio in
    DataLine.Info audioInDataLineInfo = new DataLine.Info(TargetDataLine.class, audioFormat);

    sourceDataLine = null;
    targetDataLine = null;
    // here we try to initialise the audio system. try catch is exception handling, i.e. 
    // dealing with things not working as expected
    try {
      sourceDataLine = (SourceDataLine) AudioSystem.getLine(audioOutDataLineInfo);
      sourceDataLine.open(audioFormat, bOutput.length);
      sourceDataLine.start();

      targetDataLine = (TargetDataLine) AudioSystem.getLine(audioInDataLineInfo);
      targetDataLine.open(audioFormat, bInput.length);
      targetDataLine.start();

      running = true;
    } 
    catch (LineUnavailableException lue) {
      // it went wrong!
      lue.printStackTrace(System.err);
      System.out.println("Could not initialise audio. check above stack trace for more info");
      //System.exit(1);
    }
  }
  // we are ovverriding the run method from the Thread class
  // run gets called when the thread starts
  public @Override
    // We must implement run, this gets triggered by start()
  void run () {
    while (running) {
      // read from audio in to the float input array
      targetDataLine.read(bInput, 0, bInput.length);
      // generate the float buffer
      generateAudioOut(fOutputs[0]);
      // convert to bytes and send it to the card
      sourceDataLine.write(floatsToBytes(fOutputs, bOutput), 0, bOutput.length);
    }
  }

  // returns the current contents of the audio buffer
  public float[] getAudio() {
    return fOutputs[0];
  }

  // Our method that quits the thread
  // taken from http://wiki.processing.org/w/Threading
  public void quit() {
    System.out.println("Quitting audio thread."); 
    running = false;  // Setting running to false ends the loop in run()
    sourceDataLine.drain();
    sourceDataLine.close();  
    // IUn case the thread is waiting. . .
    // note that the interrupt method is defined in the Thread class which we are extending
    interrupt();
  }
  // this method is not general, it just assumes 2 bytes per sample and a single input channel
  private float[] bytesToFloats(byte[] bData, float[] fData) {
    for (int i=0;i<bData.length;i+=2) {
      twoBytes[0] = bData[i];
      twoBytes[1] = bData[i+1]; 
      fData[i/2] = twoBytesToFloat(twoBytes);
      //if (i % 4000 == 0){
      //     println("f: "+fData[i/2]);
      //}
    }
    return fData;
  }

  // hacked mercilessly out of the AudioFileIn class
  // written by 'AA' (see other tab...)
  // it assumes that the buffer contains enough bytes for one sample
  // e.g. if 16 bit, 2 bytes. 

  private float twoBytesToFloat(byte[] b) {
    float sample = 0.0f;
    int ret = 0;
    int length = b.length;
    //for (int i = 0; i < b.length; i++, length--) {
    ret |= ((int) (b[0] & 0xFF) << ((((false) ? length : (1)) * 8) - 8));
    ret |= ((int) (b[1] & 0xFF) << ((((false) ? length : (2)) * 8) - 8));
    if (ret > 0x7FFF) {
      ret = ~ret + 1;
      ret &= 0x7FFF;
      ret = ~ret + 1;
    }
    sample = (float) ((float) ret / (float) Short.MAX_VALUE);
    return sample;
  }


  /**
   * Converts a float audio array [-1,1] to an interleaved array of 16-bit samples
   * in little-endian (low-byte, high-byte) format.
   */
  private byte[] floatsToBytes(float[][] fData, byte[] bData) {
    int index = 0;
    for (int i = 0; i < blockSize; i++) {
      for (int j = 0; j < numOutputs; j++) {
        short sval = (short) (fData[j][i] * ShortMaxValueAsFloat);
        bData[index++] = (byte) (sval & 0x00FF);
        bData[index++] = (byte) ((sval & 0xFF00) >> 8);
      }
    }
    return bData;
  }
}


class Ball
{
  PVector p, v; //position, velocity
  float r; //radius of the pong ball
  
  Ball()
  {
    r = 25;
    p = new PVector(400,400,-10); //Starting position at the centre of the screen
    v = new PVector(random(3,8),random(3,8),-10); //Starting direction is randomised to vary up the gameplay
  }
  
  public void draw()
  {
    pushMatrix();
      fill(0,255,0);
      translate (p.x,p.y,p.z); //translates the sphere to p
      sphere(r); //Draws a basic sphere
    popMatrix();
  }
  
  public void move()
  {
    p.add(v); //Moves the ball based on velocity
    v = bounce(p, v); //bounce the ball of the x y and z faces
  }
  
  public PVector bounce(PVector p, PVector v)
  {
    float x=check(p.x,v.x, court.cS); //updates the x coordinate of the velocity (returns the same if not at a face)
    float y=check(p.y,v.y, court.cS); //updates the y coordinate the same
    float z=zCheck(p.z,v.z, court.cD); //Updates the z coordinate based on whether or not it is at a face - a unique function as there are more factors to consider when the z cooridnate reaches a face
    PVector temp = new PVector(x,y,z); 
    return temp; //returns the new velocity vector
  }
  
  public float check(float a, float b, float c) //basic check if the x or y coordinates go beyond the side and top faces and then reverses direction if it is
  {
    if ((a-r<0)&&(b<0)) {return b*-1;} 
    else if ((a+r>c)&&(b>0)) {return b*-1;}
    else {return b;}
  }
  
  public float zCheck(float a, float b, float c)
  {
    if ((a-r>0)&&(b>0)) //Checks if ball hits the screen 
    {
      if (p.x>(mouseX-player.paddle.r)&&p.x<(mouseX+player.paddle.r)&&p.y>(mouseY-player.paddle.r)&&p.y<(mouseY+player.paddle.r)) //checks if the ball lands on the paddle
      {
        return b*-1; //reverses the direction if it does
      }
      else
      {
        gameStage = 2; //ends the game if the player doesn't manage to catch the ball 
        player.scoreCalc(); 
        return b;
      }
    }
    else if ((a+r<c)&&(b<0)) //Checks if ball hits the far wall
    {
      for (int i=0; i<court.board.length;i++)
      {
        court.board[i].press(p.x,p.y); //confirms which board was hit and activates it 
      }
      return b*-1; //bounces back
    }
    else 
    {
      return b;
    }
  }
}
class Court
{
  float cS,cD; //court Size and court Depth
  Plate[] board; //sets up the plates that make up the far wall
  float[] notes; //sets up the notes for the plates
  
  Court()
  {
    cS = width; //courtsize equal to screen size
    cD = -2*width; //depths double the screed size but extending back
    
    setupNotes();
    
    int n = PApplet.parseInt(cS/6); //width of plates designed to ensure they fill the back wall
    board = new Plate[36]; //36 plates for 36 notes
    for (int i=0;i<6;i++)
    {
      for (int j=0;j<6;j++)
      {
        board[(i*6)+j] = new Plate(j*n,i*n,cD+5, n, notes[(i*6)+j]); //creates boards with x y z coordinates, width/height, and note frequencies
      }
    }
  }
  
  public void run() //draws the court the game is played on
  {
    fill(125);
    pushMatrix();
      for (float i=cD;i<0;i+=40)
      {
        fill(255,0,0,50);//Gradient background to create more interesting visuals
        beginShape();
          vertex(0,0,0); //Background for the ceiling
          vertex(0,0,i);
          vertex(width,0,i);
          vertex(width,0,i);
        endShape();
        beginShape();
          vertex(0,height,i); //Background for the floor
          vertex(0,height,i);
          vertex(width,height,i);
          vertex(width,height,0);
        endShape();
        beginShape();
          vertex(0,0,i); //Background for the left wall 
          vertex(0,0,i);
          vertex(0,height,i);
          vertex(0,height,0);
        endShape();
        beginShape();
          vertex(width,0,0); //Background for the right wall
          vertex(width,0,i);
          vertex(width,height,i);
          vertex(width,height,i);
        endShape();
      }
      fill(255,0,0); //Coloured line marking the location of the ball
      
      beginShape(); //Line on the left wall
        vertex(2,0,player.ball.p.z+50); 
        vertex(2,0,player.ball.p.z-50); //b[3].z+
        vertex(2,height,player.ball.p.z-50); //b[4].z+
        vertex(2,height,player.ball.p.z+50);
      endShape();
      beginShape(); //Line on the Right wall
        vertex(width-2,0,player.ball.p.z+50); 
        vertex(width-2,0,player.ball.p.z-50); //b[3].z+
        vertex(width-2,height,player.ball.p.z-50); //b[4].z+
        vertex(width-2,height,player.ball.p.z+50);
      endShape();
      beginShape(); //Line on the Ceiling
        vertex(0,2,player.ball.p.z+50); 
        vertex(0,2,player.ball.p.z-50); //b[3].z+
        vertex(width,2,player.ball.p.z-50); //b[4].z+
        vertex(width,2,player.ball.p.z+50);
      endShape();
      beginShape(); //Line on the Floor
        vertex(2,height-2,player.ball.p.z+50); 
        vertex(2,height-2,player.ball.p.z-50); //b[3].z+
        vertex(width,height-2,player.ball.p.z-50); //b[4].z+
        vertex(width,height-2,player.ball.p.z+50);
      endShape();
      
      for (int i=0;i<board.length;i++)
      {
        board[i].draw(); //draws the background boards
      }
    popMatrix();
  }
  
  public void setupNotes() //Note frequencies taken from this table: http://www.phy.mtu.edu/~suits/notefreqs.html and confirmed using a guitar tuner app 
  {
    notes = new float[36];
    notes[0] = 65.41f; //C2
    notes[1] = 69.30f; //C#2
    notes[2] = 73.42f; //D2
    notes[3] = 77.78f; //D#2
    notes[4] = 82.41f; //E2
    notes[5] = 87.31f; //F2
    notes[6] = 92.50f; //F#2
    notes[7] = 98.00f; //G2
    notes[8] = 103.83f; //G#2
    notes[9] = 110.00f; //A2
    notes[10] = 116.54f; //A#2
    notes[11] = 123.47f; //B2
    
    notes[12] = 130.81f; //C3
    notes[13] = 138.59f; //C#3
    notes[14] = 146.83f; //D3
    notes[15] = 155.56f; //D#3
    notes[16] = 164.83f; //E3
    notes[17] = 174.61f; //F3
    notes[18] = 185.00f; //F#3
    notes[19] = 196.00f; //G3
    notes[20] = 207.65f; //G#3
    notes[21] = 220.00f; //A3
    notes[22] = 233.08f; //A#3
    notes[23] = 246.94f; //B3
    
    notes[24] = 261.63f; //C4
    notes[25] = 277.18f; //C#4
    notes[26] = 293.66f; //D4
    notes[27] = 311.13f; //D#4
    notes[28] = 329.63f; //E4
    notes[29] = 349.23f; //F4
    notes[30] = 369.99f; //F#4
    notes[31] = 392.00f; //G4
    notes[32] = 415.30f; //G#4
    notes[33] = 440.00f; //A4
    notes[34] = 466.16f; //A#4
    notes[35] = 493.88f; //B4
  }  
}

class Paddle 
{
  float r; //radius of the head of the paddle
  
  Paddle()
  {
    r = 100;
  }
  
  public void draw()
  {
    pushMatrix();
      fill(50);
      noStroke();
      translate(mouseX,mouseY); //translates to the mouse position
      if(mouseX>width/2) {rotate(PI/3);} //rotates so the paddle is tilted depending on which side of the screen it is on
      else {rotate(-PI/3);}
      rect(-15,0,30,r+10); //draws the handle of the paddle
      stroke(2);
      fill(200,0,0);
      ellipse(0,0,r,r); //draws circle for the head of the paddle
    popMatrix();
  }
  
}

class Plate //Sets up the plates that make up the breakout style blocks that the ball activates
{
  PVector p; //position of the plates
  float w; //width of plates
  boolean pressed; //pressed or not
  int c; 
  float freq; //the 'note' that the plate plays
  
  Plate(float x, float y,float z, float a, float f)
  {
    w = a;
    p = new PVector(x,y,z);
    pressed = false;
    c = color(PApplet.parseInt(random(150,255)),0,0); //colour randomised to make a bit more of an interesting backdrop
    freq = f;
  }
  
  public void draw()
  {
    if (pressed) {fill(c);} //lights up with unique colour if the paddle is activated
    else {fill(255,0,0,40);} //faded colour to make a distinc difference between activated and not
    pushMatrix();
      translate(p.x,p.y,p.z);//moves the square to the correct coordinates
      rect(0,0,w,w);
    popMatrix();
  }
  
  public void press(float x, float y) //marks the plate as activated if the ball lands within it's height and width
  {
    if (x>=p.x&&x<p.x+w)
    {
      if (y>=p.y&&y<p.y+w)
      {
        pressed = !pressed;
        player.score++;
      }
    }
  }
  
  public float sing(float x)
  {
    if (pressed)
    {
      return sin(x*freq); //returns the sine of the current phase multiplied by the plate's frequency (the note set up in the Court class). 
    }
    else 
    {
      return sin(0); //returns 0 if the plate hasn't been pressed
    }
  }
  
}

class Player
{
  Ball ball; //The player has their ball that they bounce against the wall
  Paddle paddle; //mouse controls the player's paddle
  int score; //score is basic and less important than the sounds created
  
  Player()
  {
    ball = new Ball();
    paddle = new Paddle();
    score=0;
  }
  
  public void run()
  {
    ball.draw();
    ball.move();
    paddle.draw();
  }
  
  public void scoreCalc()
  {
    score = score*(millis()/100); //Number of pressed plates multiplied by the number of seconds that have passed to give it the illusion of a higher number (stamina play = higher score)
  }
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "musicalPingPong" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
